<?php

	// MailChimp
	$listID = "LIST-ID";
	$APIKey = "API-KEY";

	// Database
	$host = 'YOUR-HOST';
	$username = 'YOUR-USER';
	$password = 'YOUR-PASSWORD';
	$database = 'TEMPLATE-DATABASE';

	// Contact
	$to = 'contact@golfdivotee.com';
    $subject = 'Subject here...';

	// Variant
	$useMailChimp = "YES";

?>
